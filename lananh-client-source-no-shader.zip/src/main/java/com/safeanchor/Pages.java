package com.safeanchor;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.ClickableWidget;
import net.minecraft.client.gui.widget.SliderWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.text.Text;

import java.util.ArrayList;
import java.util.List;
import java.util.function.*;

/** Toàn bộ trang cài đặt (tiếng Việt). */
public class Pages {
    static MinecraftClient mc() { return MinecraftClient.getInstance(); }
    static Config C() { return Config.I; }

    // ---------- widget helpers ----------
    static Text onoff(String l, boolean on) { return Text.literal(l + ": " + (on ? "§aBẬT" : "§cTẮT")); }

    static Supplier<ClickableWidget> toggle(String label, BooleanSupplier g, Consumer<Boolean> s) {
        return () -> {
            ButtonWidget[] b = new ButtonWidget[1];
            b[0] = ButtonWidget.builder(onoff(label, g.getAsBoolean()), x -> { s.accept(!g.getAsBoolean()); b[0].setMessage(onoff(label, g.getAsBoolean())); Config.save(); })
                    .dimensions(0, 0, 220, 20).build();
            return b[0];
        };
    }
    static Supplier<ClickableWidget> cycle(String label, String[] names, IntSupplier g, IntConsumer s) {
        return () -> {
            ButtonWidget[] b = new ButtonWidget[1];
            b[0] = ButtonWidget.builder(Text.literal(label + ": §e" + names[g.getAsInt() % names.length]), x -> {
                s.accept((g.getAsInt() + 1) % names.length);
                b[0].setMessage(Text.literal(label + ": §e" + names[g.getAsInt() % names.length])); Config.save();
            }).dimensions(0, 0, 220, 20).build();
            return b[0];
        };
    }
    static Supplier<ClickableWidget> button(String label, Runnable r) {
        return () -> ButtonWidget.builder(Text.literal(label), x -> r.run()).dimensions(0, 0, 220, 20).build();
    }
    static Supplier<ClickableWidget> color(String label, IntSupplier g, IntConsumer s) {
        return () -> ButtonWidget.builder(Text.literal("Màu " + label + " §7(chạm để chỉnh)"),
                x -> mc().setScreen(new ColorScreen(label, mc().currentScreen, g, s))).dimensions(0, 0, 220, 20).build();
    }
    static Supplier<ClickableWidget> slider(String label, double min, double max, boolean integer, DoubleSupplier g, DoubleConsumer s) {
        return () -> new SliderWidget(0, 0, 220, 20, Text.empty(), (g.getAsDouble() - min) / (max - min)) {
            { updateMessage(); }
            double val() { return min + value * (max - min); }
            @Override protected void updateMessage() {
                double v = val(); setMessage(Text.literal(label + ": " + (integer ? String.valueOf((int) Math.round(v)) : String.format("%.1f", v))));
            }
            @Override protected void applyValue() { double v = val(); s.accept(integer ? Math.round(v) : v); }
        };
    }
    static void open(Function<Screen, Screen> f) { mc().setScreen(f.apply(mc().currentScreen)); }

    // ---------- trang ----------
    public static Screen main(Screen parent) {
        List<Supplier<ClickableWidget>> m = new ArrayList<>();
        m.add(button("⚙ Chung", () -> open(Pages::general)));
        m.add(button("🪽 Elytra Mace", () -> open(Pages::mace)));
        m.add(button("💎 Crystal / Pearl / Anchor", () -> open(Pages::crystal)));
        m.add(button("👁 ESP người / rương / mob", () -> open(Pages::esp)));
        m.add(button("🎯 Dây ESP (tracer)", () -> open(Pages::tracer)));
        m.add(button("⛏ ESP Block (quặng, block tùy chọn)", () -> open(Pages::blockEsp)));
        m.add(button("📡 Radar & đếm người", () -> open(Pages::radar)));
        m.add(button("🏗 Xây theo Schematic", () -> open(Pages::printer)));
        return new MenuScreen("Menu chính", parent, m);
    }

    static Screen general(Screen p) {
        List<Supplier<ClickableWidget>> m = new ArrayList<>();
        m.add(toggle("Bật toàn bộ mod", () -> C().enabled, v -> C().enabled = v));
        m.add(toggle("Hiện tiêu đề LAN ANH CLIENT", () -> C().showTitle, v -> C().showTitle = v));
        m.add(toggle("Auto Totem (tay trái)", () -> C().autoTotem, v -> C().autoTotem = v));
        m.add(slider("Ô hotbar chứa totem", 1, 9, true, () -> C().totemSlot, v -> C().totemSlot = (int) v));
        m.add(slider("Ô hotbar tạm (đổi đồ)", 1, 9, true, () -> C().spareSlot, v -> C().spareSlot = (int) v));
        m.add(slider("Tầm với (reach)", 3, 6, false, () -> C().reach, v -> C().reach = v));
        return new MenuScreen("Chung", p, m);
    }

    static Screen mace(Screen p) {
        List<Supplier<ClickableWidget>> m = new ArrayList<>();
        m.add(toggle("Elytra Mace (tự bay tìm & đánh)", () -> C().autoMace, v -> { if (v != C().autoMace) ElytraMace.toggle(mc()); }));
        m.add(cycle("Góc nhìn", new String[]{"Giữ nguyên", "Ngôi thứ nhất", "Ngôi 3 (sau)", "Ngôi 3 (trước)"}, () -> C().maceView, v -> C().maceView = v));
        m.add(slider("Tầm tìm đối thủ", 10, 128, true, () -> C().maceRange, v -> C().maceRange = v));
        m.add(slider("Độ cao lao xuống", 6, 40, true, () -> C().maceDiveDist, v -> C().maceDiveDist = v));
        m.add(slider("Khoảng ngang để lao", 4, 40, true, () -> C().maceHorizDive, v -> C().maceHorizDive = v));
        m.add(slider("Máu tối thiểu", 0, 20, true, () -> C().minSelfHealth, v -> C().minSelfHealth = v));
        m.add(toggle("Tự đổi áo <-> cánh", () -> C().maceSwapChest, v -> C().maceSwapChest = v));
        m.add(toggle("Dùng pháo hoa", () -> C().maceUseRocket, v -> C().maceUseRocket = v));
        return new MenuScreen("Elytra Mace", p, m);
    }

    static Screen crystal(Screen p) {
        List<Supplier<ClickableWidget>> m = new ArrayList<>();
        m.add(toggle("Auto Crystal", () -> C().crystal, v -> C().crystal = v));
        m.add(toggle("Tự đặt Obsidian", () -> C().crystalAutoObs, v -> C().crystalAutoObs = v));
        m.add(toggle("Crystal theo chỗ Pearl rơi", () -> C().pearlCrystal, v -> C().pearlCrystal = v));
        m.add(slider("Tầm đặt/nổ", 3, 6, false, () -> C().crystalRange, v -> C().crystalRange = v));
        m.add(slider("Khoảng cách nổ tới đối thủ", 2, 8, false, () -> C().crystalExplodeDist, v -> C().crystalExplodeDist = v));
        m.add(slider("Sát thương tự nhận tối đa", 1, 20, true, () -> C().maxSelfDamage, v -> C().maxSelfDamage = v));
        m.add(slider("Delay (tick)", 1, 10, true, () -> C().crystalDelay, v -> C().crystalDelay = (int) v));
        m.add(toggle("Safe Anchor (đặt là tự nổ)", () -> C().anchor, v -> C().anchor = v));
        m.add(toggle("Anchor: tự đặt obsidian chắn", () -> C().anchorSafe, v -> C().anchorSafe = v));
        return new MenuScreen("Crystal / Pearl / Anchor", p, m);
    }

    static Screen esp(Screen p) {
        List<Supplier<ClickableWidget>> m = new ArrayList<>();
        m.add(toggle("ESP người chơi", () -> C().espPlayers, v -> C().espPlayers = v));
        m.add(toggle("ESP mob", () -> C().espMobs, v -> C().espMobs = v));
        m.add(toggle("ESP rương / ender / shulker / thùng", () -> C().espStorage, v -> C().espStorage = v));
        m.add(cycle("Kiểu hộp", new String[]{"Chỉ viền", "Chỉ khối đặc", "Viền + khối"}, () -> C().espMode, v -> C().espMode = v));
        m.add(slider("Độ đậm khối", 10, 200, true, () -> C().espAlpha, v -> C().espAlpha = (int) v));
        m.add(slider("Tầm ESP", 16, 256, true, () -> C().espRange, v -> C().espRange = v));
        m.add(color("người chơi", () -> C().espPlayerColor, v -> C().espPlayerColor = v));
        m.add(color("mob", () -> C().espMobColor, v -> C().espMobColor = v));
        m.add(color("rương", () -> C().espChestColor, v -> C().espChestColor = v));
        m.add(color("ender chest", () -> C().espEnderColor, v -> C().espEnderColor = v));
        m.add(color("shulker", () -> C().espShulkerColor, v -> C().espShulkerColor = v));
        return new MenuScreen("ESP", p, m);
    }

    static final String[] TR = {"Tắt", "1: Trên màn hình", "2: Giữa màn hình", "3: Dưới màn hình"};
    static Screen tracer(Screen p) {
        List<Supplier<ClickableWidget>> m = new ArrayList<>();
        m.add(cycle("Dây người chơi", TR, () -> C().trPlayer, v -> C().trPlayer = v));
        m.add(cycle("Dây mob", TR, () -> C().trMob, v -> C().trMob = v));
        m.add(cycle("Dây rương", TR, () -> C().trChest, v -> C().trChest = v));
        m.add(cycle("Dây ender chest", TR, () -> C().trEnder, v -> C().trEnder = v));
        m.add(cycle("Dây shulker", TR, () -> C().trShulker, v -> C().trShulker = v));
        m.add(cycle("Dây block", TR, () -> C().trBlock, v -> C().trBlock = v));
        m.add(toggle("Dùng màu riêng cho dây (theo vị trí)", () -> C().tracerOwnColor, v -> C().tracerOwnColor = v));
        m.add(color("dây loại 1 (trên)", () -> C().tracerColor1, v -> C().tracerColor1 = v));
        m.add(color("dây loại 2 (giữa)", () -> C().tracerColor2, v -> C().tracerColor2 = v));
        m.add(color("dây loại 3 (dưới)", () -> C().tracerColor3, v -> C().tracerColor3 = v));
        return new MenuScreen("Dây ESP", p, m);
    }

    static Screen blockEsp(Screen p) {
        List<Supplier<ClickableWidget>> m = new ArrayList<>();
        m.add(toggle("Bật ESP block", () -> C().espBlocks, v -> C().espBlocks = v));
        m.add(toggle("Quặng", () -> C().espBlkOres, v -> C().espBlkOres = v));
        m.add(toggle("Tiện ích (lò, bàn craft...)", () -> C().espBlkUtility, v -> C().espBlkUtility = v));
        m.add(toggle("Đặc biệt (spawner, anchor...)", () -> C().espBlkSpecial, v -> C().espBlkSpecial = v));
        m.add(slider("Tầm quét", 16, 128, true, () -> C().espBlkRange, v -> C().espBlkRange = v));
        m.add(color("quặng", () -> C().espBlkOreColor, v -> C().espBlkOreColor = v));
        m.add(color("tiện ích", () -> C().espBlkUtilityColor, v -> C().espBlkUtilityColor = v));
        m.add(color("đặc biệt", () -> C().espBlkSpecialColor, v -> C().espBlkSpecialColor = v));
        m.add(color("block tùy chỉnh", () -> C().espBlkCustomColor, v -> C().espBlkCustomColor = v));
        m.add(button("➕ Thêm / xóa block tùy chỉnh", () -> open(Pages::customBlocks)));
        return new MenuScreen("ESP Block", p, m);
    }

    static Screen customBlocks(Screen p) {
        List<Supplier<ClickableWidget>> m = new ArrayList<>();
        TextFieldWidget[] tf = new TextFieldWidget[1];
        m.add(() -> { tf[0] = new TextFieldWidget(mc().textRenderer, 0, 0, 220, 20, Text.literal("id")); tf[0].setPlaceholder(Text.literal("vd: diamond_block")); tf[0].setMaxLength(64); return tf[0]; });
        m.add(button("➕ Thêm block này", () -> {
            String s = tf[0].getText().trim().toLowerCase();
            if (!s.isEmpty() && !C().espBlkCustom.contains(s)) { C().espBlkCustom.add(s); Config.save(); }
            mc().setScreen(customBlocks(p));
        }));
        for (String id : new ArrayList<>(C().espBlkCustom))
            m.add(button("❌ Xóa: " + id, () -> { C().espBlkCustom.remove(id); Config.save(); mc().setScreen(customBlocks(p)); }));
        return new MenuScreen("Block tùy chỉnh", p, m);
    }

    static Screen radar(Screen p) {
        List<Supplier<ClickableWidget>> m = new ArrayList<>();
        m.add(toggle("Radar", () -> C().radarOn, v -> C().radarOn = v));
        m.add(toggle("Radar: hiện đầu người chơi", () -> C().radarPlayers, v -> C().radarPlayers = v));
        m.add(toggle("Radar: hiện block ESP", () -> C().radarBlocks, v -> C().radarBlocks = v));
        m.add(slider("Kích thước radar", 50, 200, true, () -> C().radarSize, v -> C().radarSize = (int) v));
        m.add(slider("Tầm radar (block)", 16, 128, true, () -> C().radarRange, v -> C().radarRange = v));
        m.add(slider("Vị trí radar ngang (%)", 0, 100, true, () -> C().radarX, v -> C().radarX = (int) v));
        m.add(slider("Vị trí radar dọc (%)", 0, 100, true, () -> C().radarY, v -> C().radarY = (int) v));
        m.add(toggle("Hiện số người chơi", () -> C().counterOn, v -> C().counterOn = v));
        m.add(slider("Vị trí số người ngang (%)", 0, 100, true, () -> C().counterX, v -> C().counterX = (int) v));
        m.add(slider("Vị trí số người dọc (%)", 0, 100, true, () -> C().counterY, v -> C().counterY = (int) v));
        return new MenuScreen("Radar & đếm người", p, m);
    }

    static Screen printer(Screen p) {
        List<Supplier<ClickableWidget>> m = new ArrayList<>();
        m.add(toggle("Bật Printer (tự xây)", () -> C().printerOn, v -> C().printerOn = v));
        m.add(button("Đã nạp: " + (Printer.loadedName == null ? "(chưa có)" : Printer.loadedName) + " - chạm để chọn file",
                () -> open(Pages::schemList)));
        m.add(button("Đặt gốc xây tại chỗ đang đứng", () -> { Printer.setOriginHere(); Util.msg("Đã đặt gốc schematic tại vị trí của bạn"); }));
        m.add(slider("Delay (tick giữa các lần đặt)", 1, 20, true, () -> C().printerDelay, v -> C().printerDelay = (int) v));
        m.add(slider("Số block mỗi lần", 1, 10, true, () -> C().printerPerTick, v -> C().printerPerTick = (int) v));
        m.add(slider("Tầm đặt", 3, 6, false, () -> C().printerRange, v -> C().printerRange = v));
        m.add(toggle("Tự chỉnh hướng block (xoay đúng hướng)", () -> C().printerFixRotate, v -> C().printerFixRotate = v));
        m.add(toggle("Tự chỉnh note/repeater/comparator", () -> C().printerClicks, v -> C().printerClicks = v));
        m.add(toggle("Giữ shift khi đặt (tránh mở rương/bàn)", () -> C().printerSneak, v -> C().printerSneak = v));
        return new MenuScreen("Xây theo Schematic", p, m);
    }

    static Screen schemList(Screen p) {
        List<Supplier<ClickableWidget>> m = new ArrayList<>();
        List<String> files = Printer.list();
        if (files.isEmpty()) m.add(button("Chưa có file .litematic trong thư mục /schematics", () -> {}));
        for (String f : files)
            m.add(button(f, () -> {
                try { Printer.load(f); Util.msg("Đã nạp " + f + " (" + Printer.blocks.size() + " block)"); }
                catch (Exception e) { Util.msg("§cLỗi nạp schematic: " + e.getMessage()); }
                mc().setScreen(printer(((MenuScreen) p).parent));
            }));
        return new MenuScreen("Chọn schematic (.minecraft/schematics)", p, m);
    }
}
